export default class Answer {
    constructor(answer) {
        this.ans = answer.ans;
        this.lp = answer.lp;
        this.points = answer.points;
    }
}
