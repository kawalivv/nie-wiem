/**
 * @enum {TEAMS}
 */
const TEAMS = {
    BLUE: 'blue',
    RED: 'red'
};

Object.freeze(TEAMS);

export default TEAMS;
